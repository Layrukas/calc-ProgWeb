var tabVal, tab;
function load( ) {
tabVal = document.getElementById("tabVal");
 tab = document.getElementById("tab");
 genTab();
}
function genTab() {
    tab.value = "";
    var val = Number(tabVal.value),
    line;
    for ( var i=1; i <= 9 ; ++i ){
    line= val + " X " + i +
    " = " + ( val * i );
    tab.value += line + "\n";
    }
    line= val+" X 10 = "+(val*10);
    tab.value += line;
   }
   