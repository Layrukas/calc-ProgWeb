 var imagens= new Array("cascaCaracol.png",
 "Fibbonaci.png",
"universo.png",
"urina.jpg"),
 current = 0, // Imagem visualizada
 image, legend;


 function change() {
    image.src = imagens[current];
    image.alt= imagens[current];
    legend.firstChild.data = imagens[current];
    }
function load() {
    image = document.getElementById("image");
    legend = document.getElementById("legend");
    file = document.getElementById("file");
    change();
   }
   function next() {
    if (++current == imagens.length) current = 0;
    change();
   }
   function prev() {
    if (current-- == 0) current = imagens.length - 1;
    change();
   } 
   function show() {
    if ( isValid(file.value) ) {
    current = find( file.value);
    if (current == imagens.length)
    imagens[imagens.length] = file.value;
    change();
    }
   }
   function isValid(str) {
    return Number(str)!=0 || !isNaN( parseInt(str) );
   }
   function find( fileName) {
    for (var i=0;i < imagens.length; ++i)
   {
    if ( imagens[i] == fileName )
    return i;
    return imagens.length;
   }
}