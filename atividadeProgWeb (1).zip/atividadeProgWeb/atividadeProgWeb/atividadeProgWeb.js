
var msg;
function load(){
    msg =document.getElementById("msg");
}

var LESS_THAN = "O número que pensou é menor que ";
function go() {
 var min= 0, max= 32, num;
 do {
 num= Math.round( (max+min)/2 );
 if ( confirm(LESS_THAN + num ) )
 max = num-1;
 else min = num;
 } while(min != max);
 numberIs( min );
}

var MSG_OUT = "O número que pensou foi ";
function numberIs( n ) {
 while ( msg.hasChildNodes() ) {
 var c = msg.firstChild;
 msg.removeChild(c);
 }
 while ( msg.hasChildNodes() ) {
    var c = msg.firstChild;
    msg.removeChild(c);
   }
var tn=document.createTextNode(MSG_OUT+n);
msg.appendChild( tn );   
}