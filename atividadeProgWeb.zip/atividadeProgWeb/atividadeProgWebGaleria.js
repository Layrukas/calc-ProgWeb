function load() {
    image = document.getElementById("image");
    legend = document.getElementById("legend");
    file = document.getElementById("file");
    change();
   }
   function next() {
    if (++current == imagens.length) current = 0;
    change();
   }
   function prev() {
    if (current-- == 0) current = imagens.length - 1;
    change();
   } 